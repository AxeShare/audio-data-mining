import numpy as np
from matplotlib import pyplot as plt
import scipy.io.wavfile as wav
from numpy.lib import stride_tricks
import networkx as nx
import matplotlib.pyplot as plt
import numpy.linalg
from itertools import combinations
import librosa.feature
import librosa.display
from os import path
from pydub import AudioSegment
import os


src = "transcript.mp3"
dirr = 'fma_small/0'
count = 1
for count in range(0:99):
	dirrr = dirr + str(count/10) + str(count%10)
        
	for src in os.listdir(dirrr):
		dst = "test.wav"
                print(str(dirrr))
		# convert wav to mp3        
		sss = dirrr+'/'+src                                                    
		sound = AudioSegment.from_mp3(sss)
		sound.export(dst, format="wav")


                tamples, sample_rate = librosa.load(dst)
    		chroma = librosa.feature.chroma_stft(tamples)
   		plt.figure(figsize=(10, 4))
   		librosa.display.specshow(chroma, y_axis='chroma', x_axis='time')
   		plt.colorbar()
   		plt.title('Chromagram')
   		plt.tight_layout()
                src.split('.')
                plt.savefig(src.split('.')[0] + '.' + 'png')
                plt.cla()
                plt.clf()
       

	plt.close('all')

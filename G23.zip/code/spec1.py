import scipy
import matplotlib.pyplot as plt
import scipy.io.wavfile
import os
from os import path
from pydub import AudioSegment
from apscheduler.scheduler import Scheduler
import secrets
import tensorflow
import theano
for d in os.listdir("./fma_small/"):
	print(d)
	for src in os.listdir("./fma_small/"+d):
		print(src)
		dst = "test.wav"
		sound = AudioSegment.from_mp3("/home/yash/cs685/proj/fma_small/"+d+"/"+src)
		sound.export(dst, format="wav")
		
		rate, data = scipy.io.wavfile.read('test.wav')
		fig,ax = plt.subplots(1)
		fig.subplots_adjust(left=0,right=1,bottom=0,top=1)
		ax.axis('off')
		if(data.ndim==2):
			pxx, freqs, bins, im = ax.specgram(x=data[:441000,0], Fs=rate)
		else:
			pxx, freqs, bins, im = ax.specgram(x=data[:441000], Fs=rate)
		ax.axis('off')
		fig.savefig("/home/cs685/proj/wav/"+src+".jpg", dpi=300, frameon='false')
		plt.close(fig)
exit()

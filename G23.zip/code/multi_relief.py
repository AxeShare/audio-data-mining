import numpy as np
import csv

data = np.genfromtxt("sort_class_features.csv", delimiter=",", skip_header=1)
data1=data.copy()

for k in range(3, 512):
	for i in range(1, 8000):
		a1=1
		for j in range(1, 1601):
			if j!=i:
				a1 = min(a1, abs(data[i][k] - data[j][k]))
		a2=1
		for j in range(1601, 3203):
			if j!=i:
				a2 = min(a2, abs(data[i][k] - data[j][k]))
		a3=1
		for j in range(3203, 4804):
			if j!=i:
				a3 = min(a3, abs(data[i][k] - data[j][k]))
		a4=1
		for j in range(4804, 6405):
			if j!=i:
				a4 = min(a4, abs(data[i][k] - data[j][k]))
		a5=1
		for j in range(6405, 8000):
			if j!=i:
				a5 = min(a5, abs(data[i][k] - data[j][k]))

		if i>=1 and i<1601:
			hit=a1
			miss=(a2+a3+a4+a5)/4
			data1[i][k]=data[i][k]-hit+miss
		if i>=1601 and i<3203:
			hit=a2
			miss=(a1+a3+a4+a5)/4
			data1[i][k]=data[i][k]-hit+miss
		if i>=3203 and i<4804:
			hit=a3
			miss=(a1+a2+a4+a5)/4
			data1[i][k]=data[i][k]-hit+miss
		if i>=4804 and i<6405:
			hit=a4
			miss=(a1+a2+a3+a5)/4
			data1[i][k]=data[i][k]-hit+miss
		if i>=6405 and i<8000:
			hit=a5
			miss=(a1+a2+a3+a4)/4
			data1[i][k]=data[i][k]-hit+miss

a = []

for k in range(3, 512):
	b=0
	for i in range(1, 8000):
		b=b+data1[i][k]
	a.append(b)

np.savetxt("relief_weight.csv", data1, delimiter=",")
np.savetxt("relief_sum.csv", a, delimiter=",")

import numpy as np
from matplotlib import pyplot as plt
import scipy.io.wavfile as wav
from numpy.lib import stride_tricks
import networkx as nx
from visibility_graph import visibility_graph
import matplotlib.pyplot as plt
import numpy.linalg
from apscheduler.scheduler import Scheduler
import secrets
import tensorflow
import theano
""" short time fourier transform of audio signal """
def stft(sig, frameSize, overlapFac=0.5, window=np.hanning):
    win = window(frameSize)
    hopSize = int(frameSize - np.floor(overlapFac * frameSize))

    # zeros at beginning (thus center of 1st window should be for sample nr. 0)   
    samples = np.append(np.zeros(int(np.floor(frameSize/2.0))), sig)    
    # cols for windowing
    cols = np.ceil( (len(samples) - frameSize) / float(hopSize)) + 1
    # zeros at end (thus samples can be fully covered by frames)
    samples = np.append(samples, np.zeros(frameSize))

    frames = stride_tricks.as_strided(samples, shape=(int(cols), frameSize), strides=(samples.strides[0]*hopSize, samples.strides[0])).copy()
    frames *= win

    return np.fft.rfft(frames)    

""" scale frequency axis logarithmically """    
def logscale_spec(spec, sr=44100, factor=20.):
    timebins, freqbins = np.shape(spec)

    scale = np.linspace(0, 1, freqbins) ** factor
    scale *= (freqbins-1)/max(scale)
    scale = np.unique(np.round(scale))

    # create spectrogram with new freq bins
    newspec = np.complex128(np.zeros([timebins, len(scale)]))
    for i in range(0, len(scale)):        
        if i == len(scale)-1:
            newspec[:,i] = np.sum(spec[:,int(scale[i]):], axis=1)
        else:        
            newspec[:,i] = np.sum(spec[:,int(scale[i]):int(scale[i+1])], axis=1)

    # list center freq of bins
    allfreqs = np.abs(np.fft.fftfreq(freqbins*2, 1./sr)[:freqbins+1])
    freqs = []
    for i in range(0, len(scale)):
        if i == len(scale)-1:
            freqs += [np.mean(allfreqs[int(scale[i]):])]
        else:
            freqs += [np.mean(allfreqs[int(scale[i]):int(scale[i+1])])]

    return newspec, freqs

""" plot spectrogram"""
def plotstft(audiopath, binsize=2**10, plotpath=None, colormap="jet"):
    samplerate, samples = wav.read(audiopath)
    if(samples.ndim==2):
       sampl = np.transpose(samples)[1]
    else:
        sampl = samples
    fvt = np.zeros(300)
    for i in range(1,300):
       summ=0
       for j in range(1,400):
           summ += sampl[i*100+j]
    avgg = summ/400
    fvt[i]=avgg

    g = visibility_graph(fvt[0:300])
    #nx.draw(g)
    #print(fvtime)
    #plt.show()
    f1 = nx.average_shortest_path_length(g)
    print(str(f1))
    f2 = nx.transitivity(g)
    print(str(f2))
    L = nx.normalized_laplacian_matrix(g)
    e = numpy.linalg.eigvals(L.A)
    f3 = max(e)    #spectral radius
    print(str(f3))
    f4 = nx.average_clustering(g)
    print(str(f4))
    fl = open('features.csv','a')

    f3 = f3 - 1.99
    f3 = f3*100
    fl.close()
    return f1,f2,f3,f4

f = open('graph_features.csv','a')
from os import path
from pydub import AudioSegment
import os
# files                                                                         
src = "transcript.mp3"
for src in os.listdir('fma_small/003'):
	dst = "test.wav"

	# convert wav to mp3        
	sss = 'fma_small/001/'+src                                                    
	sound = AudioSegment.from_mp3(sss)
	sound.export(dst, format="wav")



	f.write(src)
	f.write(', ')
	f1,f2,f3,f4 = plotstft("test.wav")
	f.write(str(f2))
	f.write(', ')

	f.write(str(f3))

	f.write(', ')
	f.write(str(f1))

	f.write(', ')
	f.write(str(f4))
	f.write('\n')
f.close()

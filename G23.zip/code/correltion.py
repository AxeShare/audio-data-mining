from pandas import read_csv
import numpy as np

dataset = read_csv('copy_features.csv', header=0)
x = dataset.corr()

#np.savetxt("corr.csv", x, delimiter=",")

vi = np.zeros(518)

reduced_data = np.zeros((518,1))

thr=0.5

for i in range(0, 518):
	if vi[i]==0:
		vi[i]=1
		count = 0
		new = np.zeros((518,1))
		for j in range(0, 518):
			if x[i][j]>thr:
				count+=1
				new+=dataset[:,j]	
				
		new=new/count
		np.append(reduced_data,new,axis=1)

np.savetxt("reduced.csv", reduced_data, delimiter=",") 

import pandas as pd
import os
from apscheduler.scheduler import Scheduler
import secrets
import tensorflow
import theano
f = pd.read_csv('data_listen_sort.csv')
for g in os.listdir("/home/yash/cs685/proj/wav2/"):
	os.system("mv /home/yash/cs685/proj/wav2/" + g + " /home/yash/cs685/proj/popularity/" + f[f.track_id==int(g[:6])]['class'].to_string(index=False))



